<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="container-fluid bg-grey">
  <h2 class="text-center">BUILD RESUME</h2>
  <form action="form.php" method="POST">
      <div class="row">
          <div>
              <th><h2>Description:</h2><textarea>write here</textarea></th>
             
          </div>
          <div>
            <input class="form-control" id="email1" name="email" placeholder="Skill" rows="3" type="email" required><br>
          </div>
          <div>
           <input class="form-control" id="contact1" name="contact" placeholder="Education & qualification" rows="4" required><br>
          </div>
          <div>
        <input class="form-control" id="password1" name="password" placeholder="interest" rows="5" type="password" required><br>
        </div>
        <div>
           <input class="form-control" id="contact1" name="contact" placeholder="languages" rows="4" required><br>
          </div>
      </div>
      
       
      <div class="row">
        <div class="col-sm-12 form-group">
     <button class="btn btn-default pull-right" type="submit">REGISTER</button>
        </div>
      </div>
      </form>
  </div>
</body>
</html>