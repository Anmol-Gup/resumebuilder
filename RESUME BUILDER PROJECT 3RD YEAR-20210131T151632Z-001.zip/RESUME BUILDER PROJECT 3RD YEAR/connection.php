<?php

    $username='root';
    $server='localhost';
    $password='';
    $db='resume';

    $con=mysqli_connect($server,$username,$password,$db);

    if($con)
        echo "<script>alert('Connection Successful!');</script>";
    else
        die("No Connection".mysqli_connect_error());
?>