<?php
include 'connection.php';

$id=$_GET['id'];

// retrieving personal details, education & qualifications
$selectquery1="select * from form where id='$id'";
$res1=mysqli_query($con,$selectquery1);

// retrieving interests  
$selectquery2="SELECT i.interests FROM form as f INNER JOIN interest_table as i ON f.id = i.fid and f.id=$id";
$res2=mysqli_query($con,$selectquery2);

// retrieving skills
$selectquery3="SELECT s.skills_name FROM form as f INNER JOIN skills as s ON f.id = s.sid and  f.id=$id";
$res3=mysqli_query($con,$selectquery3);

// retrieving work experience
$selectquery4="SELECT w.company,w.role,w.startyear,w.endyear FROM form as f INNER JOIN work_experience as w ON f.id = w.wid and  f.id=$id";
$res4=mysqli_query($con,$selectquery4);

// retrieving language
$selectquery5="SELECT  l.lname FROM form as f INNER JOIN language as l ON f.id = l.lid and  f.id=$id";
$res5=mysqli_query($con,$selectquery5);

// counting whether data exists or not.
$count1=$count=mysqli_num_rows($res1);
$count2=$count=mysqli_num_rows($res2);
$count3=$count=mysqli_num_rows($res3);
$count4=$count=mysqli_num_rows($res4);
$count5=$count=mysqli_num_rows($res5);

if($count1==0 && $count2==0 && $count3==0 && $count4==0 && $count5==0)
{
    echo "<script>alert('Record Not Found');</script>";
    header("location:resume.html");
}
else
{
    $row1=mysqli_fetch_array($res1);
    $row4=mysqli_fetch_array($res4);
}
?>
<!doctype html>
<html lang="en">
<head>
    <title>Template 2</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="Style.css">
</head>
<body>

    <div class="container">
        <div class="header">
            <div class="full-name">
                <span class="first-name"><?php echo $row1['name']; ?></span>
            </div>
            <div class="contact-info">
                <span class="email">Email: </span>
                <span class="email-val"><?php echo $row1['email']; ?></span>
                <span class="separator"></span>
                <span class="phone">Phone: </span>
                <span class="phone-val"><?php echo $row1['phone']; ?></span>
            </div>

            <div class="about">
                <span class="position"><h6><?php echo $row4['role']; ?></h6>  </span>
                <span class="desc"><p><?php echo $row1['description']; ?></p>
        </span>
            </div>
        </div>
        <div class="details">

            <div class="section">
                <div class="section__title">Education</div>
                <div class="section__list">
                    <div class="section__list-item">
                        <div class="left">
                            <div class="name">School</div>
                            <div class="addr"><?php echo $row1['school10']; ?></div>
                        </div>
                        <div class="right">
                            <div class="name">Board</div>
                            <div class="desc"><?php echo $row1['board10']; ?></div>
                        </div>
                    </div>
                    <div class="section__list-item">
                        <div class="left">
                            <div class="name">School</div>
                            <div class="addr"><?php echo $row1['school12']; ?></div>
                        </div>
                        <div class="right">
                            <div class="name">Board</div>
                            <div class="desc"><?php echo $row1['board12']; ?></div>
                        </div>
                    </div>
                    <div class="section__list-item">
                        <div class="left">
                            <div class="name">College</div>
                            <div class="addr"><?php echo $row1['univ']; ?></div>
                        </div>
                        <div class="right">
                            <div class="name">University</div>
                            <div class="desc"><?php echo $row1['clg']; ?></div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="section">
                <div class="section__title">Languages
                </div>
                <div class="section__list">
                    <div class="section__list-item">
                        <div class="text">
                            <!--<p>English: very good command</p>
                            <p>Hindi: Native speaker</p>
                            <p>French: Working Knowledge</p>-->
                            <?php
                                while($row5=mysqli_fetch_array($res5))
                                {
                                    print_r("<p>".$row5['lname']."</p>");
                                } 
                            ?>
                        </div>


                    </div>
                </div>
                <div class="section">
                    <div class="section__title">Skills</div>
                    <?php
                    echo '<div class="skills">';
                    echo '<div class="skills__item">';
                            echo'<div class="left">';
                                echo'<div class="name">';
                                while($row3=mysqli_fetch_array($res3))
                                {
                                    print_r("<p>".ucwords($row3['skills_name'])."</p>");
                                }
                                echo'</div>';
                            echo'</div>';
                        echo'</div>';
                    echo'</div>'?>
                    <!--<div class="skills__item">
                        <div class="left">
                            <div class="name">
                                CSS
                            </div>
                        </div>
                    </div>-->
                </div>

                <div class="section">
                    <div class="section__title">Experience</div>
                    <div class="section__list">
                        <div class="section__list-item">
                            <div class="left">
                                <div class="name"><?php echo "Company: ".ucwords($row4['company']); ?></div>
                                <div class="duration"><?php echo "Duration: ".$row4['startyear']." - ".$row4['endyear']; ?></div>
                            </div>
                            <div class="right">
                                <div class="name">Role</div>
                                <div class="desc"><?php echo ucwords($row4['role']); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section">
                <div class="section__title">
                    Interests
                </div>
                <div class="section__list">
                    <div class="section__list-item">
                        <?php
                            while($row2=mysqli_fetch_array($res2))
                            {
                                print_r("<p>".ucwords($row2['interests'])."</p>");
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
   <a href="pdf2.php"> <button>DOWNLOAD HERE</button></a>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>