﻿
<!doctype html>
<html lang="en">
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-M9QKS2L');</script>
<!-- End Google Tag Manager -->

    <link rel="shortcut icon" type="image/x-icon" href="https://cdn.resumebuild.com/assets/favicon-d63ea7b04acdc4f49b81835bb4a8835196e99779597404009f2607f052837dcb.ico" />
    <meta charset="utf-8">
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta name="author" content="">
    <meta name="copyright" content="">
    <meta name="description" content="RESUME BUILDER Online. Impressive Resumes Made Easy! Get hired with the professional Resume Maker that will make you stand out from the crowd!">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

    <title>resume builder for beginner</title>
    <link rel="stylesheet" media="all" href="https://cdn.resumebuild.com/assets/screen-9b15c263e85bf361f086219d3f4515ad04e5656164300b6371f1aebd3b4c6e49.css" />
<link rel="stylesheet" media="all" href="https://cdn.resumebuild.com/assets/application-647dbfc014573a98f14e267f2447f56e952fca7e73d0f1606087cc622e1e68dd.css" />
<link rel="stylesheet" media="all" href="https://cdn.resumebuild.com/assets/cvfonts-ed605737f46ed74e99d47403b768b2955cb542d0ff46e2da2be0803e0ba149cc.css" />
    <script src="https://cdn.resumebuild.com/assets/head-24bf2e9157eaf4c783bb2417c7460eb76837461cc4f376ea5e42d7e2d41e581b.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <style>
     
     
.bg-grey {
  background-color: #f6f6f6;
}
  .container-fluid {
    padding: 60px 50px;
  }
  @media screen and (max-width: 768px) {
    .col-sm-4 {
      text-align: center;
      margin: 25px 0;
    }
  }
   .logo-small {
    color: #f4511e;
    font-size: 50px;
  }
  .logo {
    color: #f4511e;
    font-size: 200px;
  }
  .navbar {
  margin-bottom: 0;
  background-color: #f4511e;
  z-index: 9999;
  border: 0;
  font-size: 12px !important;
  line-height: 1.42857143 !important;
  letter-spacing: 4px;
  border-radius: 0;
}

.navbar li a, .navbar .navbar-brand {
  color: #fff !important;
}

.navbar-nav li a:hover, .navbar-nav li.active a {
  color: #f4511e !important;
  background-color: #fff !important;
}

.navbar-default .navbar-toggle {
  border-color: transparent;
  color: #fff !important;
}
footer .glyphicon {
  font-size: 20px;
  margin-bottom: 20px;
  color: #f4511e;
}
body {
  font: 400 15px Lato, sans-serif;
  line-height: 1.8;
  color: #818181;
}

.jumbotron {
  font-family: Montserrat, sans-serif;
}

.navbar {
  font-family: Montserrat, sans-serif;
  
}
h2 {
  font-size: 24px;
  text-transform: uppercase;
  color: #303030;
  font-weight: 600;
  margin-bottom: 30px;
}

h4 {
  font-size: 19px;
  line-height: 1.375em;
  color: #303030;
  font-weight: 400;
  margin-bottom: 30px;
}
.slideanim {visibility:hidden;}
.slide {
  /* The name of the animation */
  animation-name: slide;
  -webkit-animation-name: slide;
  /* The duration of the animation */
  animation-duration: 1s;
  -webkit-animation-duration: 1s;
  /* Make the element visible */
  visibility: visible;
}

/* Go from 0% to 100% opacity (see-through) and specify the percentage from when to slide in the element along the Y-axis */
@keyframes slide {
  0% {
    opacity: 0;
    transform: translateY(70%);
  }
  100% {
    opacity: 1;
    transform: translateY(0%);
  }
}
@-webkit-keyframes slide {
  0% {
    opacity: 0;
    -webkit-transform: translateY(70%);
  }
  100% {
    opacity: 1;
    -webkit-transform: translateY(0%);
  }
}
.thumbnail {
  padding: 0 0 15px 0;
  border: none;
  border-radius: 0;
}

.thumbnail img {
  width: 100%;
  height: 100%;
  margin-bottom: 10px;
}


      </style>
    <meta name="csrf-param" content="authenticity_token" />
<meta name="csrf-token" content="9d5D+AtUtXKgnU0Rqb+LQOUXpH+UjDV5JfYf2LFV2NBifPg7C5wKsDi2iqU04r9ir/S2xiAKZEvV7HIitU04oQ==" />
  </head>
    <body class="home  resumebuild-com en app_resumebuild_com">
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M9QKS2L"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

    <a id="top" class="sr-only" aria-hidden="true">
  Top page
</a>

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="collapse navbar-collapse" id="myNavbar">
<nav class="header__actions">
  <center>
     
    </center>
       
      <ul class="nav navbar-nav navbar-right">
        <li><a href="logup.php">LOGIN</a></li>
        <li><a  href="reg.php">REGISTER</a></li>
      </ul>
   
</nav>
</div>
</nav>
<div class="jumbotron text-center">
  <h1>Resume Builder.com</h1>
  <p><i>For Better Future......</i></p>
   <a class="header__link" href="logup.php">
    Resume templates
  </a>||
  <a class="header__link" href="template2.php">
    Resume examples
  </a>||
  <a class="header__link" href="contact.html">
   contact us
  </a>||
  <a class="header__link" href="resource.php">
   About us
  </a>
  </div>





<section class="hero">
  <div class="container">
    <div class="row">
      <div class="hero__content col-md-7">
        <h1 class="hero__heading">Impressive resumes <span class="heading-extra">Easy online builder</span></h1>

        <ul class="hero__list">
          <li>Professional out-of-the-box resumes, instantly generated by the most advanced resume builder technology available.</li>
          <li>Effortless crafting. Real-time preview & pre-written resume examples. <br>
Dozens of HR-approved resume templates.</li>
          <li>Land your dream job with the perfect resume employers are looking for!</li>
        </ul>

        <a class="btn--xlarge btn-primary" href="reg.php">Build my resume</a>
      </div>

      <div class="hero__image">
        <a href="/introduction">
          <img src="https://cdn.resumebuild.com/assets/hero-img-bbe36150001250f42a014cd4bad401178eaa616aa6ec607f762115e1a46cf701.jpg" />
</a>      </div>
    </div>
  </div>
</section>

<section class="landing-steps landing-section landing-section--alt">
  <div class="container">
    <div class="landing-section-header">
      <h2 class="landing-heading">
        3 EASY STEPS TO CREATE YOUR perfect RESUME
      </h2>
    </div>

    <div class="row landing-steps__steps">
      <a href="">
        <div class="landing-steps__step col-md-4">
          <div class="landing-steps__step-icon"><img src="https://cdn.resumebuild.com/assets/icon-cv-fb4b6b2810d55d5480c5275bf38f67f1820eea55e82b07347b09963c5ec9efe7.svg" /></div>
          <h3 class="landing-steps__step-title">Choose your<br />resume template</h3>
          <p class="landing-steps__step-info">Our professional resume templates are designed strictly following all industry guidelines and best practices</br> employers are looking for.</p>
          <!-- TODO: <a href="#" class="landing-steps__step-btn">View our templates</a> -->
        </div>

        <div class="landing-steps__step col-md-4">
          <div class="landing-steps__step-icon"><img src="https://cdn.resumebuild.com/assets/icon-pen-3c10fefc5c8094adab81f509baa0625208887d1557c66dfe678d586cd8b8c09f.svg" /></div>
          <h3 class="landing-steps__step-title">Show what <br />you're made of</h3>
          <p class="landing-steps__step-info">Not finding the right words to showcase yourself? We've added thousands of pre-written examples and resume samples.  </br>As easy as a click.</p>
          <!-- TODO: <a href="#" class="landing-steps__step-btn">View our examples</a> -->
        </div>

        <div class="landing-steps__step col-md-4">
          <div class="landing-steps__step-icon"><img src="https://cdn.resumebuild.com/assets/icon-download2-9f518b607f810b4239b34a2d4f92ce038dfe7f112a8729137cd3eea3bac37530.svg" /></div>
          <h3 class="landing-steps__step-title">Download <br /> Your resume</h3>
          <p class="landing-steps__step-info">Start impressing employers. Download your awesome resume and land the job you are looking for, effortlessly. </p>
          <!-- TODO: <a href="#" class="landing-steps__step-btn">View our tips</a> -->
        </div>
</a>    </div>
  </div>
</section>

<footer class="footer landing-section--alt">
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-sm-3 col-xs-12 col-xxs-6">
        <div class="footer__content">
          <ul class="nav">
            <li><a href="logup.php" title="Resume builder">Resume builder</a></li>
            <li><a href="template2.php" title="Resume templates">Resume templates</a></li>
          </ul>
        </div>
      </div>

      <div class="col-md-3 col-sm-3 col-xs-12 col-xxs-6">
        <div class="footer__content">
          <ul class="nav">
            <li><a href="logup.php" title="Professional resume">Professional resume</a></li>
                      <li><a href="logup.php" title="Student resume">Student resume</a></li>
          </ul>
        </div>
      </div>

      <div class="col-md-3 col-sm-3 col-xs-12 col-xxs-6">
        <div class="footer__content">
          <ul class="nav">
            <li><a href="contact.html" title="Contact us">Contact us</a></li>
            <li><a href="resource.php" title="Privacy policy">Privacy policy</a></li>
            <li><a href="resource.php" title="Terms and conditions">Terms and conditions</a></li>
          </ul>
        </div>
      </div>

      <div class="col-md-3 col-sm-3 col-xs-12 col-xxs-6">
     
      </div>
    </div>

    <div class="footer__legal">
      <div class="footer__brand">
        <div class="footer__brand-logo">
           
        <!-- <div class="footer__copy">
        </div> -->
      </div>
    </div>
  </div>
</footer>
</div>

<!--sign_up-->
 
   


  <script>
 
   $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
  </script>
 </body>