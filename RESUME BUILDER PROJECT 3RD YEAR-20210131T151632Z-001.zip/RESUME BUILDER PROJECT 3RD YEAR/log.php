<?php
$con =mysqli_connect("localhost","root","","login");
mysqli_select_db($con,'login');

$name=$_POST['name'];
$password=$_POST['pswd'];
 $s="select * from `login`.`form2` where name='$name' && password='$password'";
$res=mysqli_query($con,$s);
$num=mysqli_num_rows($res);
if($num==1){
    header('Location:resume.html');
}
else{
    echo "<script>alert('Record Not Found please go back and register yourself!!');</script>";
    
   
}

?>