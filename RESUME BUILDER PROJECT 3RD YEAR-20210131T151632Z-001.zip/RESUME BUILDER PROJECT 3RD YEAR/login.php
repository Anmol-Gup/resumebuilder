
<?php
$_SERVER="localhost";
$_username="root";
$_password="";

$conn=mysqli_connect($_SERVER,$_username,$_password);

if(!$conn){
    echo "<script>
            alert('Connection Failed!!.mysqli_connect_error()');
            window.location.href='index.php';
            </script>";            

}
 
$name1=$_POST['name'];
$email1=$_POST['email'];
$password1=$_POST['password'];
$contact1=$_POST['contact'];
                 //DBMS   //table
//$sql="INSERT INTO `form`.`form` (`name1`, `email1`, `contact1`, `password1`) VALUES ";
               //             (name)                                                         (id name=database name)                                                      
$sql=" INSERT INTO `login`. `form2` ( `name`, `email`, `password`,`id`,`contact`) VALUES('$name1', '$email1','$password1',NULL,'$contact1') ";

if($conn->query($sql)==true){
    echo " <script>window.location.href='resume.php'</script>";
 
}

else{
    echo"ERROR:$sql<br> $conn->error";
}
$conn->close();

?>
