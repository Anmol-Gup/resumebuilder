<?php
 require_once 'dompdf/autoload.inc.php';
 use Dompdf\Dompdf;
 $doc=new Dompdf();
 //$doc->loadHtml();
 $page=file_get_contents("display.php");
 $doc->loadHtml($page);
 $doc->setPaper('A4','potrait');
 $doc->render();
 $doc->stream("resume",array("Attachment=>1"));
?>