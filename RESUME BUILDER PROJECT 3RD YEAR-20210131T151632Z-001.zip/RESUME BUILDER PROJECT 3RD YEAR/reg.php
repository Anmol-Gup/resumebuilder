<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=email], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=password], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=number], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
<body>
    <h2 class="text-center">SIGN UP</h2>
    <div class="container-fluid bg-grey" id="login">

  <form action="login.php" method="POST">
      <div class="row">
          <div>
            <input class="form-control" id="name1" name="name" placeholder="Name"  rows="2" type="text" required><br><br>
          </div>
          <div>
            <input class="form-control" id="email1" name="email" placeholder="Email" rows="3" type="email" required><br>
          </div>
          <div>
           <input class="form-control" id="contact1" name="contact" placeholder="Contact number" type="number" rows="4" required><br>
          </div>
          <div>
        <input class="form-control" id="password1" name="password" placeholder="Type any password" rows="5" type="password" required><br>
        </div>
      </div>
      
       
      <div class="row">
        <div class="col-sm-12 form-group">
     <input class="btn btn-default pull-right" type="submit" value="Register"> 
        </div>
      </div>
      </form>
  </div>
</body>
</html>