<?php
 include 'connection.php';

 if(isset($_POST['submit']))
 {
    // Personal Details
    $description=$_POST['myself'];
    $name=$_POST['username'];
    $email=$_POST['mail'];
    $phone=$_POST['phone'];
    $addr=$_POST['address'];

    // Education Details 
    $board10=$_POST['boardX'];
    $school10=$_POST['schoolX'];
    $university=$_POST['university'];
    $college=$_POST['college'];
    $board12=$_POST['boardxll'];
    $school12=$_POST['schoolxll'];

    // Interest, Skills & Languages
    $interest=$_POST['interest'];
    $dirs = explode(',', $interest);
    $skill=$_POST['skill'];
    $lang=$_POST['languages'];

    // Work Experience
    $company_name=$_POST['org'];
    $role=$_POST['role'];
    $syear=$_POST['startyear'];
    $eyear=$_POST['endyear'];
    
    $insertquery1="insert into form (name,address,email,phone,description,board10,school10,board12,school12,univ,clg) values ('$name','$addr','$email','$phone','$description','$board10','$school10','$board12','$school12','$university','$college')";
    $res1=mysqli_query($con,$insertquery1);
    $last_id = mysqli_insert_id($con);
    
    
    // inserting work experience
    $insertquery2="insert into work_experience(company,role,startyear,endyear,wid) values ('$company_name','$role','$syear','$eyear','$last_id')";
    $res2=mysqli_query($con,$insertquery2);

    // inserting interests
    foreach($dirs as $xid=>$i){
     
        $sql = "INSERT INTO interest_table(fid,interests) VALUES('$last_id','$i')";
        $res3=mysqli_query($con,$sql);
    }

    // inserting skills
    for($i=0;$i<count($skill);$i++){
     
        $j = "insert into skills(sid,skills_name) VALUES ('$last_id','$skill[$i]')";
        $res4=mysqli_query($con,$j);
    }

    // inserting languages
    foreach($lang as $y=>$a){
     
        $k = "insert into language(lid,lname) VALUES ('$last_id','$a')";
        $res5=mysqli_query($con,$k);
    }

    if($res1 && $res2 && $res3 && $res4 && $res5)
    {
        echo "<script>alert('Congrats,'.$name.'Data Successfully Inserted!');</script>";
    }
    else
    {
        echo "<script>alert('OOps,'.$name.'Data Not Successfully Inserted! There is some issue.');</script>";
        header('location:resume.html');
    }

    header("location:resume_form.php?id=$last_id");
 }
 else
    echo "<script>alert('Some Error Occured!');</script>";
?>