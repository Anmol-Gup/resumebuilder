<?php
  include 'connection.php';
  $id=$_GET['id'];
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <title>Resume Templates</title>
    <link rel='stylesheet' href='resume_form.css'>
  </head>
  <body>
    <!--Nav Bar-->
    <nav class="nav-bar">
      <ul class="nav justify-content-center">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">About Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Contact Us</a>
        </li>
      </ul>
    </nav>
    <hr>
    <h1 class="template">Select Template</h1><hr><br>
    <section class="container">
      <div class="container img1">
        <form method="GET">
          <a type="submit" name='save' href="show.php?id=<?php echo $id;?>" class="btn btn-light">
            <img src="template1.jpeg" class="img-fluid rounded mx-auto d-block template1" alt="Failed Too Load...">
          </a>
        </form>
      </div><br><br>
      <div class="container img1">
        <form  method="GET">
          <a type="submit" name="submit" href="display.php?id=<?php echo $id;?>" class="btn btn-light">
            <img src="template2.jpeg" class="img-fluid rounded mx-auto d-block template2" alt="Failed Too Load...">
          </a>
        </form>
      </div>
    </section>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
  </body>
</html>