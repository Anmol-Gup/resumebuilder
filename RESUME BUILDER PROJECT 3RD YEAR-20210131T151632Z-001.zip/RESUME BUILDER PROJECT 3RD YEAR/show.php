<?php
include 'connection.php';

$id=$_GET['id'];

// retrieving personal details, education & qualifications
$selectquery1="select * from form where id='$id'";
$res1=mysqli_query($con,$selectquery1);

// retrieving interests  
$selectquery2="SELECT i.interests FROM form as f INNER JOIN interest_table as i ON f.id = i.fid and f.id=$id";
$res2=mysqli_query($con,$selectquery2);

// retrieving skills
$selectquery3="SELECT s.skills_name FROM form as f INNER JOIN skills as s ON f.id = s.sid and  f.id=$id";
$res3=mysqli_query($con,$selectquery3);

// retrieving work experience
$selectquery4="SELECT w.company,w.role,w.startyear,w.endyear FROM form as f INNER JOIN work_experience as w ON f.id = w.wid and  f.id=$id";
$res4=mysqli_query($con,$selectquery4);

// retrieving language
$selectquery5="SELECT  l.lname FROM form as f INNER JOIN language as l ON f.id = l.lid and  f.id=$id";
$res5=mysqli_query($con,$selectquery5);

// counting whether data exists or not.
$count1=$count=mysqli_num_rows($res1);
$count2=$count=mysqli_num_rows($res2);
$count3=$count=mysqli_num_rows($res3);
$count4=$count=mysqli_num_rows($res4);
$count5=$count=mysqli_num_rows($res5);

if($count1==0 && $count2==0 && $count3==0 && $count4==0 && $count5==0)
{
    echo "<script>alert('Record Not Found');</script>";
    header("location:resume.html");
}
else
{
    $row1=mysqli_fetch_array($res1);
    $row4=mysqli_fetch_array($res4);
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume</title>
    <style>
        *{
            font-family: Arial, Helvetica, sans-serif;'
        }
    </style>
</head>

<body background-color="#D5D8DC;">
    <div class="container" style=" display: flex; justify-content: center; border: 5px solid black; margin-left: 17.249%; margin-right: 16%;">
        <table width=" 700px " ; height="100vh " ; text-align="center " ;>
            <tr>
                <td style="color:white; padding:10px; height: 0%; width:20%; background-color:#1C2833; ">
                    <h2>Personal details</h2>
                    <hr>
                    <p>Name: <br> <?php echo $row1['name']; ?> <br><br> Address: <br> <?php echo $row1['address']; ?><br>
                        <br><br> Phone number: <br> <?php echo $row1['phone']; ?>
                        <br><br>Phone number: <br> <?php echo $row1['email']; ?>
                    </p>
                    <h2>Interest</h2>
                    <hr>
                    <!--<p>Sports</p>
                    <p>Cooking</p>
                    <p>Reading</p>-->
                    <?php
                        while($row2=mysqli_fetch_array($res2))
                        {
                            print_r("<p>".$row2['interests']."</p>");
                        }
                    ?>
                    <h2>Languages</h2>
                    <hr>
                    <?php
                        while($row5=mysqli_fetch_array($res5))
                        {
                            print_r("<p>".$row5['lname']."</p>");
                        }
                    ?>
                    <!--<p>English: very good command</p>
                    <p>Hindi: Native speaker</p>
                    <p>French: Working Knowledge</p>-->
                    <h2>Skills</h2>
                    <hr>
                    <?php
                        while($row3=mysqli_fetch_array($res3))
                        {
                            print_r("<p>".$row3['skills_name']."</p>");
                        } 
                    ?>
                    <!--<p>Javascript</p>
                    <p> CSS</p>-->
                </td>
                <td style="padding:10px; background-color:#F8F9F9; ">
                    <h1><?php echo $row1['name'];?></h1>
                    <hr>
                    <p> 
                        <?php
                            echo "<h3>".$row1['description'].'</h3><br>';
                        ?>
                    </p>
                    <h2>Work Experience</h2>
                    <hr>
                    <h3><?php  echo "Role: ".$row4['role']; ?></h3>
                    <h3><?php echo "Company: ".$row4['company']; ?></h3>
                    <p>
                        <h3><?php  echo "Duration: ".$row4['startyear']." - ".$row4['endyear'].'<br>'; ?></h3>
                    </p><br>
                    <h2> Education and Qualifications</h2>
                    <hr>
                    <h3><?php  echo "Passed Class 10 from ".$row1['school10']." affiliated to ".$row1['board10']."." ?></h3>
                    <h3><?php  echo "Passed Class 12 from ".$row1['school12']." affiliated to ".$row1['board12']."." ?></h3>
                    <h3><?php  echo "Graduation from ".$row1['clg']." affiliated to ".$row1['univ']."." ?></h3>
                </td>
            </tr>
        </table>
    </div>
</body>
<form action="pdf1.php" method="POST">
<button name="button" type="submit" class="btn-btn-sucess">DOWNLOAD HERE</form></button>
</html>