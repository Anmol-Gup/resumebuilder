 

<!doctype html>
<html lang="en">

<head>
    <title>Template 2</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="Style.css">
</head>

<body>
    <div class="container">
        <div class="header">
            <div class="full-name">
                <span class="first-name">Sneha Tripathi </span>
                 
            </div>
            <div class="contact-info">
                <span class="email">Email: </span>
                <span class="email-val">john.wick@xyz</span>
                <span class="separator"></span>
                <span class="phone">Phone: </span>
                <span class="phone-val">111-222-3333</span>
            </div>

            <div class="about">
                <span class="position"><h6>Front-End Developer</h6>  </span>
                <span class="desc"><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptates quo deleniti, fuga asperiores necessitatibus neque consectetur eos mollitia aliquid corrupti sunt vero, esse cupiditate consequatur eius, fugit praesentium et ea!
                Dolores maxime consequatur error vitae officia esse, ducimus incidunt reiciendis harum eaque quasi beatae nemo minima sit vel animi vero dicta omnis nulla accusantium velit. Maxime sapiente sequi provident repudiandae?
                Nesciunt, reprehenderit. Laboriosam expedita sequi dignissimos, deserunt odit laborum doloremque illo quod pariatur eius voluptatem molestiae, in non. Ad eaque magni laborum officia laudantium. Laboriosam nemo debitis mollitia facilis ea!
                Doloremque, aut natus, eveniet ut et architecto illum est maiores itaque ipsam tempore excepturi dicta. Cum deleniti exercitationem et incidunt repellat ad consectetur ea labore omnis explicabo libero, modi dolorum!
                Repellat ad impedit consectetur tenetur odio, praesentium ut est omnis cum ducimus accusamus molestias quas et, velit laudantium ex commodi optio corporis sint quidem a iusto nesciunt. Magni, eius tempore!</p>
      </span>
            </div>
        </div>
        <div class="details">
            <div class="section">
                <div class="section__title">Experience</div>
                <div class="section__list">
                    <div class="section__list-item">
                        <div class="left">
                            <div class="name">KlowdBox</div>
                            <div class="addr">San Fr, CA</div>
                            <div class="duration">Jan 2011 - Feb 2015</div>
                        </div>
                        <div class="right">
                            <div class="name">Fr developer</div>
                            <div class="desc">did This and that</div>
                        </div>
                    </div>
                    <div class="section__list-item">
                        <div class="left">
                            <div class="name">Akount</div>
                            <div class="addr">San Monica, CA</div>
                            <div class="duration">Jan 2011 - Feb 2015</div>
                        </div>
                        <div class="right">
                            <div class="name">Fr developer</div>
                            <div class="desc">did This and that</div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="section">
                <div class="section__title">Education</div>
                <div class="section__list">
                    <div class="section__list-item">
                        <div class="left">
                            <div class="name">Sample Institute of technology</div>
                            <div class="addr">San Fr, CA</div>
                            <div class="duration">Jan 2011 - Feb 2015</div>
                        </div>
                        <div class="right">
                            <div class="name">Fr developer</div>
                            <div class="desc">did This and that</div>
                        </div>
                    </div>
                    <div class="section__list-item">
                        <div class="left">
                            <div class="name">Akount</div>
                            <div class="addr">San Monica, CA</div>
                            <div class="duration">Jan 2011 - Feb 2015</div>
                        </div>
                        <div class="right">
                            <div class="name">Fr developer</div>
                            <div class="desc">did This and that</div>
                        </div>
                    </div>

                </div>

            </div>
            <div class="section">
                <div class="section__title">Projects</div>
                <div class="section__list">
                    <div class="section__list-item">
                        <div class="name">
                        <form action="form.php" method="post">
                            <h6>Description</h6>
                        <div class="text">
                            <p></p>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="section" action="index.php">
                <div class="section__title">Skills</div>
                <?php echo $skill; 
                ?>
                </div>
            </div>

        </div>
        <div class="section">
            <div class="section__title">
                Interests
            </div>
            <div class="section__list">
                <div class="section__list-item">
                    Football, programming.
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>